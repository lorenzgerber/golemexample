alertme = function(){
  alert("simple js!");
}