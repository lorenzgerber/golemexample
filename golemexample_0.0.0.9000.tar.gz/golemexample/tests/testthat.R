library(testthat)
library(golemexample)

test_check("golemexample")
